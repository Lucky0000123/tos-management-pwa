import { TOSManager } from '@/components/TOSManager';

export default function Index() {
  return <TOSManager />;
}
